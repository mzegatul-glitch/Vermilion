-- =====================================================
-- Vermilion
-- Core/Init.lua
-- Engine Bootstrap
-- =====================================================

local AddOn, Engine = ...

-- Lua / WoW API
local CreateFrame = CreateFrame
local UnitGUID = UnitGUID
local UnitName = UnitName
local UnitClass = UnitClass
local UnitRace = UnitRace
local UnitLevel = UnitLevel
local GetLocale = GetLocale
local GetRealmName = GetRealmName
local GetCVar = GetCVar
local GetAddOnMetadata = GetAddOnMetadata
local GetBuildInfo = GetBuildInfo
local ReloadUI = ReloadUI

----------------------------------------------------------
-- Engine Tables
----------------------------------------------------------

Engine[1] = CreateFrame("Frame") -- V
Engine[2] = {}                   -- C
Engine[3] = {}                   -- L
Engine[4] = {}                   -- Private

local V = Engine[1]

function Engine:unpack()
    return self[1], self[2], self[3], self[4]
end

----------------------------------------------------------
-- Globals
----------------------------------------------------------

Vermilion = Engine

----------------------------------------------------------
-- Helpers
----------------------------------------------------------

V.Noop = function() end

----------------------------------------------------------
-- AddOn Info
----------------------------------------------------------

V.AddOn = AddOn
V.Client = GetLocale()
V.Realm = GetRealmName()

V.Version = GetAddOnMetadata(AddOn, "Version") or "0"
V.VersionNumber = tonumber((V.Version:gsub("%.", ""))) or 0

V.WoWPatch,
V.WoWBuild,
V.WoWPatchReleaseDate,
V.TocVersion = GetBuildInfo()

----------------------------------------------------------
-- Resolution
----------------------------------------------------------

V.Resolution = GetCVar("gxResolution")

local width, height = V.Resolution:match("(%d+)x(%d+)")

V.ScreenWidth = tonumber(width) or 0
V.ScreenHeight = tonumber(height) or 0

----------------------------------------------------------
-- Player Info
----------------------------------------------------------

function V:UpdatePlayerInfo()

    self.Unit = UnitGUID("player")
    self.Name = UnitName("player")
    self.Class = select(2, UnitClass("player"))
    self.Race = select(2, UnitRace("player"))
    self.Level = UnitLevel("player")

    self.Color = (CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS)[self.Class]

end

----------------------------------------------------------
-- Events
----------------------------------------------------------

V:RegisterEvent("PLAYER_LOGIN")

V:SetScript("OnEvent", function(self, event)

    if event == "PLAYER_LOGIN" then
        self:UpdatePlayerInfo()
    end

end)

----------------------------------------------------------
-- Slash Commands
----------------------------------------------------------

SLASH_RELOADUI1 = "/rl"
SLASH_RELOADUI2 = "/reloadui"

SlashCmdList["RELOADUI"] = ReloadUI

----------------------------------------------------------
-- Documentation
----------------------------------------------------------

--[[
Inside Vermilion:

    local V, C, L, P = select(2, ...):unpack()

or

    local V, C = select(2, ...):unpack()

External AddOns:

    local V, C, L, P = Vermilion:unpack()

The 4th table (P) is reserved for private/internal data.
]]